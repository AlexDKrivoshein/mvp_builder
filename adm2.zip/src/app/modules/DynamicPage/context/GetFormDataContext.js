import React from "react";

export const GetFormDataContext = React.createContext(
    null,
)