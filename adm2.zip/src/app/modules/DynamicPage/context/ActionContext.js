import React from "react";

export const ActionContext = React.createContext(
    null,
)